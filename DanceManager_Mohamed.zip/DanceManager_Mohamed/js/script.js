window.addEventListener('scroll', function() {
    const backgroundSection = document.querySelector('.background-section');
    if (window.scrollY > 0) {
        backgroundSection.style.opacity = '0';
    } else {
        backgroundSection.style.opacity = '1';
    }
});
